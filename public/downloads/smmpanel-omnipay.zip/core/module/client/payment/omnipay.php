<?php
if (!defined('PAYMENT')) {
    http_response_code(404);
    die();
}

$rawBody = file_get_contents("php://input");
if (!$rawBody) {
    header("Location: " . site_url("addfunds"));
    exit();
}

$apiKey = trim($methodExtras['api_key']);
$data = json_decode($rawBody, true);

// Verify X-OMNIPAY-SIGNATURE
$headers = getallheaders();
$receivedSignature = $headers['X-OMNIPAY-SIGNATURE'] ?? $headers['x-omnipay-signature'] ?? '';
$expectedSignature = hash_hmac('sha256', $rawBody, $apiKey);

if (empty($receivedSignature) || !hash_equals($expectedSignature, $receivedSignature)) {
    header("HTTP/1.1 401 Unauthorized");
    die("Invalid Signature");
}

if (isset($data['status']) && $data['status'] === 'paid') {
    $orderId = $data['meta_data']['order_id'] ?? '';
    $userId = $data['meta_data']['client_id'] ?? '';
    
    $paymentDetails = $conn->prepare("SELECT * FROM payments WHERE payment_extra=:orderId");
    $paymentDetails->execute(["orderId" => $orderId]);
    
    $userQuery = $conn->prepare("SELECT * FROM clients WHERE client_id=:id");
    $userQuery->execute(["id" => $userId]);
    $user = $userQuery->fetch(PDO::FETCH_ASSOC);

    if ($paymentDetails->rowCount() && $user) {
        $paymentDetails = $paymentDetails->fetch(PDO::FETCH_ASSOC);
        $paidAmount = floatval($paymentDetails["payment_amount"]);

        $update = $conn->prepare('UPDATE payments SET client_balance=:balance, payment_status=:status, payment_delivery=:delivery WHERE payment_id=:id');
        $update->execute([
            'balance' => $user["balance"],
            'status' => 3,
            'delivery' => 2,
            'id' => $paymentDetails['payment_id']
        ]);
        
        $balance = $conn->prepare('UPDATE clients SET balance = balance + :amount WHERE client_id = :id');
        $balance->execute([
            "amount" => $paidAmount,
            "id" => $user["client_id"]
        ]);
        echo "Success";
        exit;
    }
}

header("Location: " . site_url("addfunds"));
exit;