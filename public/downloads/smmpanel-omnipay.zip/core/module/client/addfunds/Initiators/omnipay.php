<?php
if (!defined('ADDFUNDS')) {
    http_response_code(404);
    die();
}

$apiKey = $methodExtras["api_key"];
$apiUrl = rtrim($methodExtras["api_url"], '/');
$currency = $methodExtras["currency"] ?? 'USDT';
$paymentURL = site_url("payment/" . $methodCallback);
$orderId = md5(RAND_STRING(5) . time());

$insert = $conn->prepare("INSERT INTO payments SET client_id=:client_id, payment_amount=:amount, payment_method=:method, payment_mode=:mode, payment_create_date=:date, payment_ip=:ip, payment_extra=:extra");
$insert->execute([
    "client_id" => $user["client_id"],
    "amount" => $paymentAmount,
    "method" => $methodId,
    "mode" => "Automatic",
    "date" => date("Y.m.d H:i:s"),
    "ip" => GetIP(),
    "extra" => $orderId
]);

$requestData = [
    'amount'         => $paymentAmount,
    'customer_name'  => $user["name"] ?: "User",
    'customer_email' => $user["email"] ?: "test@test.com",
    'currency'       => $currency,
    'callback_url'   => $paymentURL,
    'cancel_url'     => site_url(""),
    'meta_data'      => [
        'order_id'  => $orderId,
        'client_id' => $user["client_id"]
    ]
];

$ch = curl_init($apiUrl . '/api/v1/payment');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($requestData),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Accept: application/json',
        'X-API-KEY: ' . $apiKey
    ],
]);
$response = curl_exec($ch);
curl_close($ch);
$result = json_decode($response, true);

if (isset($result['payment_link'])) {
    $redirectForm = '<form method="GET" action="' . $result['payment_link'] . '" name="omnipayCheckoutForm"></form>
    <script type="text/javascript">document.omnipayCheckoutForm.submit();</script>';
    $response["success"] = true;
    $response["message"] = "Redirecting to checkout...";
    $response["content"] = $redirectForm;
} else {
    errorExit($result['error'] ?? "Failed to initialize payment.");
}