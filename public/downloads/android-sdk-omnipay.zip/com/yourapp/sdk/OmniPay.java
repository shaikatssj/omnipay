package com.yourapp.sdk;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class OmniPay {
    private String apiKey;
    private String baseUrl;

    public interface Callback {
        void onSuccess(Map<String, Object> response);
        void onFailure(String error);
    }

    public OmniPay(String apiKey, String baseUrl) {
        this.apiKey = apiKey;
        this.baseUrl = baseUrl.replaceAll("/+$", "");
    }

    public void createPayment(Map<String, Object> data, Callback callback) {
        post("/api/v1/payment", data, callback);
    }

    public void verifyKey(Callback callback) {
        get("/api/v1/verify-key", callback);
    }

    private void post(String endpoint, Map<String, Object> data, Callback callback) {
        new Thread(() -> {
            try {
                URL url = new URL(baseUrl + endpoint);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("X-API-KEY", apiKey);
                conn.setDoOutput(true);

                JSONObject jsonInput = new JSONObject(data);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(jsonInput.toString().getBytes());
                }

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    result.append(line);
                }
                in.close();

                JSONObject responseJson = new JSONObject(result.toString());
                Map<String, Object> responseMap = jsonToMap(responseJson);
                new Handler(Looper.getMainLooper()).post(() -> callback.onSuccess(responseMap));
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> callback.onFailure(e.getMessage()));
            }
        }).start();
    }

    private void get(String endpoint, Callback callback) {
        new Thread(() -> {
            try {
                URL url = new URL(baseUrl + endpoint);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("X-API-KEY", apiKey);

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    result.append(line);
                }
                in.close();

                JSONObject responseJson = new JSONObject(result.toString());
                Map<String, Object> responseMap = jsonToMap(responseJson);
                new Handler(Looper.getMainLooper()).post(() -> callback.onSuccess(responseMap));
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> callback.onFailure(e.getMessage()));
            }
        }).start();
    }

    private Map<String, Object> jsonToMap(JSONObject json) throws Exception {
        Map<String, Object> map = new HashMap<>();
        Iterator<String> keys = json.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            Object value = json.get(key);
            if (value instanceof JSONObject) {
                value = jsonToMap((JSONObject) value);
            }
            map.put(key, value);
        }
        return map;
    }
}