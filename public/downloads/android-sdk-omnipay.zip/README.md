# OmniPay Native Android SDK

Use this Java SDK wrapper to create invoices and check API keys natively from your Android applications.

## Integration
Copy `OmniPay.java` file into your application's SDK package directory. Add Internet permission in `AndroidManifest.xml`.