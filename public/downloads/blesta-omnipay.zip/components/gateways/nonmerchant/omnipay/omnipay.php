<?php

class Omnipay extends NonmerchantGateway
{
    private $meta;

    public function __construct()
    {
        $this->loadConfig(dirname(__FILE__) . DS . 'config.json');
        Loader::loadComponents($this, ['Input']);
        Language::loadLang('omnipay', null, dirname(__FILE__) . DS . 'language' . DS);
    }

    public function setMeta(array $meta = null)
    {
        $this->meta = $meta;
    }

    public function getSettings(array $meta = null)
    {
        $this->view = new View('settings', 'default');
        $this->view->setDefaultView('components' . DS . 'gateways' . DS . 'nonmerchant' . DS . 'omnipay' . DS);
        Loader::loadHelpers($this, ['Form', 'Html']);
        $this->view->set('meta', $meta);
        return $this->view->fetch();
    }

    public function editSettings(array $meta)
    {
        $rules = [
            'api_key' => [
                'valid' => [
                    'rule' => 'isEmpty',
                    'negate' => true,
                    'message' => Language::_('Omnipay.!error.api_key.valid', true),
                ],
            ],
            'api_url' => [
                'valid' => [
                    'rule' => 'isEmpty',
                    'negate' => true,
                    'message' => Language::_('Omnipay.!error.api_url.valid', true),
                ],
            ]
        ];
        $this->Input->setRules($rules);
        $this->Input->validates($meta);
        return $meta;
    }

    public function encryptableFields()
    {
        return ['api_key'];
    }

    public function setCurrency($currency)
    {
        $this->currency = $currency;
    }

    public function buildProcess(array $contact_info, $amount, array $invoice_amounts = null, array $options = null)
    {
        $notification_url = Configure::get('Blesta.gw_callback_url') 
            . Configure::get('Blesta.company_id') . '/omnipay/?client_id=' 
            . ($contact_info['client_id'] ?? null);

        $url = rtrim($this->meta['api_url'], '/') . '/api/v1/payment';
        
        $data = [
            "customer_name"  => ($contact_info['first_name'] ?? '') . ' ' . ($contact_info['last_name'] ?? ''),
            "customer_email" => $contact_info['email'] ?? 'customer@blesta.com',
            "amount"         => round($amount, 2),
            "currency"       => $this->meta['pp_currency_code'] ?? 'USDT',
            "callback_url"   => $notification_url,
            "cancel_url"     => $options['return_url'] ?? null,
            "meta_data"      => [
                'client_id' => $contact_info['client_id'] ?? null,
                'invoices'  => $this->serializeInvoices($invoice_amounts ?? [])
            ]
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json',
            'X-API-KEY: ' . $this->meta['api_key']
        ]);
        
        $response = curl_exec($ch);
        curl_close($ch);

        $res = json_decode($response, true);
        
        if (isset($res['payment_link'])) {
            header('Location: ' . $res['payment_link']);
            exit();
        } else {
            die("Initialization Error: " . ($res['error'] ?? $response));
        }
    }

    public function validate(array $get, array $post)
    {
        $rawBody = file_get_contents("php://input");
        $data = json_decode($rawBody, true);
        
        if (empty($rawBody) || empty($data)) {
            return;
        }

        $headers = getallheaders();
        $receivedSignature = $headers['X-OMNIPAY-SIGNATURE'] ?? $headers['x-omnipay-signature'] ?? '';
        $expectedSignature = hash_hmac('sha256', $rawBody, $this->meta['api_key']);

        if (empty($receivedSignature) || !hash_equals($expectedSignature, $receivedSignature)) {
            return;
        }

        if (($data['status'] ?? '') === 'paid') {
            return [
                'client_id'      => $data['meta_data']['client_id'] ?? null,
                'amount'         => $data['amount'],
                'currency'       => $data['currency'],
                'invoices'       => $this->unserializeInvoices($data['meta_data']['invoices'] ?? ''),
                'status'         => 'approved',
                'transaction_id' => $data['invoice_id']
            ];
        }
    }

    public function success(array $get, array $post)
    {
        return $this->validate($get, $post);
    }

    public function refund($reference_id, $transaction_id, $amount, $notes = null)
    {
        $this->Input->setErrors($this->getCommonError('unsupported'));
    }

    public function void($reference_id, $transaction_id, $notes = null)
    {
        $this->Input->setErrors($this->getCommonError('unsupported'));
    }

    private function serializeInvoices(array $invoices)
    {
        $str = '';
        foreach ($invoices as $i => $invoice) {
            $str .= ($i > 0 ? '|' : '') . $invoice['id'] . '=' . $invoice['amount'];
        }
        return base64_encode($str);
    }

    private function unserializeInvoices($str)
    {
        if (empty($str)) return null;
        $str = base64_decode($str);
        $invoices = [];
        $temp = explode('|', $str);
        foreach ($temp as $pair) {
            $pairs = explode('=', $pair, 2);
            if (count($pairs) != 2) continue;
            $invoices[] = ['id' => $pairs[0], 'amount' => $pairs[1]];
        }
        return $invoices;
    }
}