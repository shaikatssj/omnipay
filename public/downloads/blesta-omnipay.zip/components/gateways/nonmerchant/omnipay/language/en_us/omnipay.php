<?php
$lang['Omnipay.name'] = "OmniPay";
$lang['Omnipay.description'] = "Accept MFS, Binance Pay, and Web3 payments with OmniPay.";
$lang['Omnipay.api_key'] = "Store API Key";
$lang['Omnipay.api_url'] = "API Base URL";
$lang['Omnipay.pp_currency_code'] = "Currency Code";
$lang['Omnipay.!error.api_key.valid'] = "You must enter a valid Store API Key.";
$lang['Omnipay.!error.api_url.valid'] = "You must enter a valid OmniPay API Base URL.";