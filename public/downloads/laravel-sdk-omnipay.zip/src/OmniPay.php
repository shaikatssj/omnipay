<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class OmniPay
{
    protected $apiKey;
    protected $baseUrl;

    public function __construct(string $apiKey, string $baseUrl = 'http://localhost:8000')
    {
        $this->apiKey = $apiKey;
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    /**
     * Create a new payment invoice link.
     */
    public function createPayment(array $data)
    {
        return $this->post('/api/v1/payment', $data);
    }

    /**
     * Get a paginated list of transactions.
     */
    public function getTransactions(array $filters = [])
    {
        return $this->get('/api/v1/transactions', $filters);
    }

    /**
     * Verify credentials handshake.
     */
    public function verifyKey()
    {
        return $this->get('/api/v1/verify-key');
    }

    /**
     * Securely verify webhook payload using Store Key HMAC-SHA256 signature.
     */
    public function verifyWebhook(string $payload, string $signature): bool
    {
        $expected = hash_hmac('sha256', $payload, $this->apiKey);
        return hash_equals($expected, $signature);
    }

    protected function post(string $endpoint, array $data)
    {
        $response = Http::withHeaders([
            'Accept' => 'application/json',
            'Content-Type: application/json',
            'X-API-KEY' => $this->apiKey
        ])->post($this->baseUrl . $endpoint, $data);

        return $response->json();
    }

    protected function get(string $endpoint, array $query = [])
    {
        $response = Http::withHeaders([
            'Accept' => 'application/json',
            'X-API-KEY' => $this->apiKey
        ])->get($this->baseUrl . $endpoint, $query);

        return $response->json();
    }
}