# OmniPay Native Laravel SDK

A simple Laravel service wrapper for interacting with the OmniPay multi-store payment gateway API.

## Installation
Copy `OmniPay.php` to your `app/Services` directory.

## Usage
```php
use App\Services\OmniPay;

$gateway = new OmniPay('your_store_api_key', 'http://localhost:8000');

// Create payment
$response = $gateway->createPayment([
    'amount' => 10.00,
    'customer_name' => 'John Doe',
    'customer_email' => 'john@test.com',
    'currency' => 'USDT'
]);

$paymentLink = $response['payment_link'];
```