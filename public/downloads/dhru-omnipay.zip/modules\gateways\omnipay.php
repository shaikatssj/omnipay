<?php

class OmniPay_Service
{
    private $gateway_url;
    private $params = [];
    private $args = [];
    public $http_code = 0;

    public function __construct($params) {
        $this->params = $params;

        $portalUrl = rtrim($params['omnipay_url'], '/');
        $this->gateway_url = $portalUrl . '/api/v1/payment';

        // Convert amount from BDT to USDT/USD
        $conversionRate = floatval($params['conversion_rate'] ?? 1);
        $amountUSDT = floatval($params['amount']) / $conversionRate;
        $amount = number_format($amountUSDT, 6, '.', '');

        $systemUrl = rtrim($params['systemurl'], '/');
        
        // Callback URL should point to our omnipay.php handler at the root of Dhru
        $callbackUrl = $systemUrl . '/omnipay.php?payment=' . $params['invoiceid'];

        $customerEmail = $params['clientdetails']['email'] ?? '';
        if (empty($customerEmail) || !filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) {
            $customerEmail = 'customer@omnipay.com';
        }

        $customerName = trim(($params['clientdetails']['firstname'] ?? '') . ' ' . ($params['clientdetails']['lastname'] ?? ''));
        if (empty($customerName)) {
            $customerName = 'Client';
        }

        $this->args = [
            'amount' => $amount,
            'customer_name' => $customerName,
            'customer_email' => $customerEmail,
            'currency' => 'USDT',
            'callback_url' => $callbackUrl,
            'cancel_url' => $callbackUrl, // Set cancel_url to callback so success page returns there
            'meta_data' => [
                'invoice_id' => $params['invoiceid'],
                'expected_amount' => $amount,
                'conversion_rate' => $conversionRate
            ]
        ];
    }

    public function generate_link() {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->gateway_url);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($this->args));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'X-API-KEY: ' . $this->params['api_key']
        ]);

        $response = curl_exec($ch);
        $this->http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return [
            'raw' => $response,
            'decoded' => json_decode($response, true)
        ];
    }
}

function omnipay_config()
{
    return [
        'name' => [
            'Type' => 'System',
            'Value' => 'OmniPay Secure Payments'
        ],
        'omnipay_url' => [
            'Name' => 'OmniPay Portal URL',
            'Type' => 'text',
            'Size' => '150',
            'Description' => 'Enter your OmniPay installation URL (e.g., https://payment.yoursite.com)'
        ],
        'api_key' => [
            'Name' => 'Store API Key',
            'Type' => 'text',
            'Size' => '150',
            'Description' => 'Enter your OmniPay Store API Key'
        ],
        'conversion_rate' => [
            'Name' => 'Conversion Rate (BDT to USDT)',
            'Type' => 'text',
            'Size' => '10',
            'Default' => '1',
            'Description' => 'Enter conversion rate from BDT to USDT (e.g., 120 or 1)'
        ]
    ];
}

function omnipay_link($params)
{
    if (empty($params['omnipay_url']) || empty($params['api_key']) || empty($params['conversion_rate'])) {
        return '<p style="color:red;">OmniPay configuration is incomplete. Please check module settings.</p>';
    }

    $client = new OmniPay_Service($params);
    $responseData = $client->generate_link();
    $server_response = $responseData['decoded'];
    $raw_response = htmlentities($responseData['raw']);

    if ($client->http_code === 401 || $client->http_code === 403) {
        return '<p style="color:red;">OmniPay API authentication failed. Please check your API key.</p>
                <pre style="color:gray;background:#f9f9f9;padding:10px;border:1px solid #ddd;">Raw Response: ' . $raw_response . '</pre>';
    }

    if ($client->http_code !== 200 && $client->http_code !== 201) {
        return '<p style="color:red;">OmniPay portal is currently unavailable. Please try again later.</p>
                <pre style="color:gray;background:#f9f9f9;padding:10px;border:1px solid #ddd;">Raw Response: ' . $raw_response . '</pre>';
    }

    if (isset($server_response['error'])) {
        $errorMsg = is_array($server_response['error']) ? ($server_response['error']['message'] ?? 'Unknown error') : $server_response['error'];
        return '<p style="color:red;">Error: ' . htmlspecialchars($errorMsg) . '</p>
                <pre style="color:gray;background:#f9f9f9;padding:10px;border:1px solid #ddd;">Raw Response: ' . $raw_response . '</pre>';
    }

    if (isset($server_response['payment_link'])) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION['omnipay_invoice_' . $params['invoiceid']] = $server_response['invoice_id'];

        $conversionRate = floatval($params['conversion_rate']);
        $amountBDT = floatval($params['amount']);
        $amountUSDT = $amountBDT / $conversionRate;

        return '
            <div class="alert alert-info" style="margin-bottom: 15px; padding: 12px; background-color: #d1ecf1; border-color: #bee5eb; color: #0c5460; border-radius: 4px;">
                <strong>Amount in BDT:</strong> ' . number_format($amountBDT, 2) . '৳<br>
                <strong>Converted to USDT:</strong> ' . number_format($amountUSDT, 6) . ' USDT (Rate: 1 USDT = ' . $conversionRate . '৳)
            </div>
            <a class="btn btn-success pt-3 pb-3" style="display: block; text-align: center; font-weight: bold; width: 100%; background-color: #28a745!important; border-color: #28a745!important; color: #fff; padding: 12px; border-radius: 4px; text-decoration: none;" href="' . $server_response['payment_link'] . '">' . $params['langpaynow'] . '</a>';
    }

    return '<p style="color:red;">Payment initialization failed. Please try again.</p>
            <pre style="color:gray;background:#f9f9f9;padding:10px;border:1px solid #ddd;">Raw Response: ' . $raw_response . '</pre>';
}
