<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
date_default_timezone_set('Asia/Dhaka');

define("DEFINE_MY_ACCESS", true);
define("DEFINE_DHRU_FILE", true);
define("ROOTDIR", __DIR__);

include ROOTDIR . "/comm.php";
require ROOTDIR . "/includes/fun.inc.php";
include ROOTDIR . "/includes/gateway.fun.php";
include ROOTDIR . "/includes/invoice.fun.php";

$version = 1.0;
$GATEWAY = loadGatewayModule('omnipay');

if ($GATEWAY["active"] != 1) {
    exit(json_encode([
        'is_success' => false,
        'code' => 403,
        'message' => "Module Not Activated"
    ]));
}

function handleSuccessResponse($paymentAmount, $amountBDT, $conversionRate) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $redirectUrl = $protocol . '://' . $_SERVER['HTTP_HOST'] . '/main';

    $response = [
        'is_success' => true,
        'code' => 200,
        'message' => "Payment processed successfully",
        'amount_usdt' => $paymentAmount,
        'amount_bdt' => $amountBDT,
        'conversion_rate' => $conversionRate,
        'redirect_url' => $redirectUrl
    ];

    if (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'text/html') !== false) {
        header('Location: /confirm.php');
    } else {
        header('Content-Type: application/json');
        echo json_encode($response);
    }
    exit();
}

function get_signature_header() {
    if (isset($_SERVER['HTTP_X_OMNIPAY_SIGNATURE'])) {
        return $_SERVER['HTTP_X_OMNIPAY_SIGNATURE'];
    }
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
        if (isset($headers['X-OMNIPAY-SIGNATURE'])) {
            return $headers['X-OMNIPAY-SIGNATURE'];
        }
        if (isset($headers['x-omnipay-signature'])) {
            return $headers['x-omnipay-signature'];
        }
    }
    return '';
}

// 1. GET redirect callback verify loop (if customer redirects back to Dhru with omnipay_id)
if (isset($_GET['payment']) && isset($_GET['omnipay_id'])) {
    $altid = $_GET['payment']; // Dhru invoice ID
    $omnipay_id = $_GET['omnipay_id']; // OmniPay invoice ID

    $portalUrl = rtrim($GATEWAY['omnipay_url'], '/');
    $verifyUrl = $portalUrl . '/verify-payment';

    $verifyData = [
        'invoice_id' => $omnipay_id
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $verifyUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($verifyData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'X-API-KEY: ' . $GATEWAY['api_key'],
        'Content-Type: application/x-www-form-urlencoded'
    ]);
    
    $verifyResponse = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        exit(json_encode([
            'is_success' => false,
            'code' => 400,
            'message' => "Payment verification failed with code: " . $httpCode,
            'api_response' => $verifyResponse
        ]));
    }

    $verifyData = json_decode($verifyResponse, true);
    if (!isset($verifyData['status']) || strtolower($verifyData['status']) !== 'completed') {
        exit(json_encode([
            'is_success' => false,
            'code' => 400,
            'message' => "Payment not confirmed by OmniPay"
        ]));
    }

    // Process the payment
    $order_id = $altid;
    $user_email = $verifyData['metadata']['customer_email'] ?? '';
    $conversionRate = floatval($GATEWAY['conversion_rate'] ?? 1);
    $transactionId = $omnipay_id;

    $orderDetails = getInvoiceDetails($order_id, $user_email);

    if (!$orderDetails) {
        exit(json_encode([
            'is_success' => false,
            'code' => 404,
            'message' => "Order not found"
        ]));
    }

    if ($orderDetails['status'] != "Unpaid") {
        handleSuccessResponse(floatval($verifyData['amount']), floatval($verifyData['amount']) * $conversionRate, $conversionRate);
    }

    if (searchTxid($transactionId)) {
        handleSuccessResponse(floatval($verifyData['amount']), floatval($verifyData['amount']) * $conversionRate, $conversionRate);
    }

    $paymentAmount = floatval($verifyData['amount']);
    $amountBDT = $paymentAmount * $conversionRate;
    
    addPayment($order_id, $transactionId, $amountBDT, 0, $GATEWAY['paymentmethod']);
    handleSuccessResponse($paymentAmount, $amountBDT, $conversionRate);
}

// 2. POST background Webhook IPN handling from OmniPay
$rawBody = trim(file_get_contents("php://input"));
if (!$rawBody) {
    exit(json_encode([
        'is_success' => false,
        'code' => 400,
        'message' => "Empty request body"
    ]));
}

// Signature verification
$signatureHeader = get_signature_header();
if (empty($signatureHeader)) {
    exit(json_encode([
        'is_success' => false,
        'code' => 403,
        'message' => "Missing callback signature verification header"
    ]));
}

$calculatedSignature = hash_hmac('sha256', $rawBody, $GATEWAY['api_key']);
if (!hash_equals($calculatedSignature, $signatureHeader)) {
    exit(json_encode([
        'is_success' => false,
        'code' => 403,
        'message' => "Invalid webhook signature"
    ]));
}

$data = json_decode($rawBody, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    exit(json_encode([
        'is_success' => false,
        'code' => 400,
        'message' => "Invalid JSON data"
    ]));
}

// Validate required payment data
if (!isset($data['status'], $data['invoice_id'], $data['amount'], $data['meta_data'])) {
    exit(json_encode([
        'is_success' => false,
        'code' => 400,
        'message' => "Missing required payment fields"
    ]));
}

if (strtolower($data['status']) !== 'paid') {
    exit(json_encode([
        'is_success' => true,
        'code' => 200,
        'message' => "Invoice status is not paid (" . $data['status'] . "), ignoring update."
    ]));
}

$metaData = $data['meta_data'];
$order_id = $metaData['invoice_id'] ?? null;
if (!$order_id) {
    exit(json_encode([
        'is_success' => false,
        'code' => 400,
        'message' => "Dhru Fusion invoice ID missing from metadata"
    ]));
}

$transactionId = $data['invoice_id'];
$paymentAmount = floatval($data['amount']);
$conversionRate = floatval($metaData['conversion_rate'] ?? $GATEWAY['conversion_rate'] ?? 1);
$user_email = $data['meta_data']['customer_email'] ?? '';

$orderDetails = getInvoiceDetails($order_id, $user_email);
if (!$orderDetails) {
    exit(json_encode([
        'is_success' => false,
        'code' => 404,
        'message' => "Order not found"
    ]));
}

if ($orderDetails['status'] != "Unpaid") {
    exit(json_encode([
        'is_success' => true,
        'code' => 200,
        'message' => "Order already marked as paid"
    ]));
}

if (searchTxid($transactionId)) {
    exit(json_encode([
        'is_success' => true,
        'code' => 200,
        'message' => "Transaction already applied"
    ]));
}

$amountBDT = $paymentAmount * $conversionRate;
addPayment($order_id, $transactionId, $amountBDT, 0, $GATEWAY['paymentmethod']);

exit(json_encode([
    'is_success' => true,
    'code' => 200,
    'message' => "Webhook payment recorded successfully"
]));

// Helper functions
function getInvoiceDetails($order_id, $user_email) {
    $order_id_safe = intval($order_id);
    $query = "
        SELECT 
            i.*, 
            GROUP_CONCAT(ii.`type` SEPARATOR ',') AS item_types
        FROM `tbl_invoices` AS i
        INNER JOIN `tblUsers` AS u 
            ON i.`userid` = u.`id`
        LEFT JOIN `tbl_invoiceitems` AS ii 
            ON ii.`invoiceid` = i.`id`
        WHERE 
            i.`id` = '$order_id_safe'
        GROUP BY i.`id`
        LIMIT 1
    ";

    $result = dquery($query);
    if (!$result) {
        return false;
    }

    return mysqli_fetch_assoc($result);
}

function searchTxid($transid) {
    $result = select_query("tbl_transaction", "id", ["transid" => $transid]);
    return mysqli_num_rows($result) > 0;
}
?>
