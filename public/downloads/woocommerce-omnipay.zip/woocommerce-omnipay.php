<?php
/*
 * Plugin Name: WooCommerce OmniPay Gateway
 * Plugin URI: http://localhost:8000
 * Description: Accept payments securely via OmniPay (supporting MFS, Web3 Crypto, and Binance Pay).
 * Author: OmniPay Team
 * Version: 1.0.0
 * Requires at least: 5.2
 * Requires PHP: 7.4
 * WC requires at least: 3.0
 * WC tested up to: 8.0
 * License: GPL v2 or later
 * Text Domain: woocommerce-omnipay
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'woocommerce_omnipay_plugin_action_links');
function woocommerce_omnipay_plugin_action_links($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=omnipay') . '">' . __('Settings') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

// Declare compatibility with HPOS and Blocks
add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
});

// Initialize the gateway class
add_action('plugins_loaded', 'woocommerce_omnipay_init_gateway_class', 0);

function woocommerce_omnipay_init_gateway_class()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return; // Exit if WooCommerce isn’t active
    }

    class WC_OMNIPAY_Gateway extends WC_Payment_Gateway
    {
        private static $instance = null;

        public $show_icon;
        public $apikey;
        public $baseUrl;
        public $order_type;

        public static function get_instance()
        {
            if (null === self::$instance) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        public function __construct()
        {
            $this->id = 'omnipay';
            $this->has_fields = false;
            $this->method_title = __('OmniPay', 'woocommerce-omnipay');
            $this->method_description = __('Secure and fast payments via OmniPay.', 'woocommerce-omnipay');
            $this->supports = ['products'];

            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->get_option('title') ?: __('OmniPay', 'woocommerce-omnipay');
            $this->description = $this->get_option('description') ?: __('Pay securely via OmniPay.', 'woocommerce-omnipay');
            $this->enabled = $this->get_option('enabled');
            $this->show_icon   = $this->get_option('show_icon') === 'yes';
            
            $this->icon = '';
            if ($this->show_icon) {
                $this->icon = $this->get_option('logo_url');
                if (empty($this->icon)) $this->icon = plugins_url('assets/icon.png', __FILE__);
            }
            
            $this->apikey = sanitize_text_field($this->get_option('apikey'));
            $this->baseUrl = sanitize_text_field($this->get_option('baseUrl'));
            $this->order_type = sanitize_text_field($this->get_option('order_type'));
            
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
            add_action('woocommerce_api_' . strtolower($this->id), [$this, 'handle_webhook']);
            add_action('woocommerce_admin_order_data_after_billing_address', [$this, 'display_omnipay_order_meta'], 10, 1);
        }

        public function init_form_fields()
        {
            $this->form_fields = [
                'enabled' => [
                    'title' => __('Enable/Disable', 'woocommerce-omnipay'),
                    'type' => 'checkbox',
                    'label' => __('Enable OmniPay Gateway', 'woocommerce-omnipay'),
                    'default' => 'no',
                ],
                'title' => [
                    'title' => __('Title', 'woocommerce-omnipay'),
                    'type' => 'text',
                    'description' => __('The title displayed at checkout.', 'woocommerce-omnipay'),
                    'default' => __('OmniPay', 'woocommerce-omnipay'),
                    'desc_tip' => true,
                ],
                'description' => [
                    'title' => __('Description', 'woocommerce-omnipay'),
                    'type' => 'textarea',
                    'description' => __('The description displayed at checkout.', 'woocommerce-omnipay'),
                    'default' => __('Pay securely via OmniPay.', 'woocommerce-omnipay'),
                    'desc_tip' => true,
                ],
                'logo_url' => [
                    'title' => __('Logo URL', 'woocommerce-omnipay'),
                    'type' => 'text',
                    'description' => __('Enter the URL of the logo to display at checkout.', 'woocommerce-omnipay'),
                    'default' => '',
                    'desc_tip' => true,
                ],
                'show_icon' => [
                    'title'   => __('Show Icon', 'woocommerce-omnipay'),
                    'type'    => 'checkbox',
                    'label'   => __('Display icon on checkout page', 'woocommerce-omnipay'),
                    'default' => 'yes',
                ],
                'order_type' => [
                    'title'       => __('Order Type', 'woocommerce-omnipay'),
                    'type'        => 'select',
                    'description' => __('Choose how the order should be handled after payment.', 'woocommerce-omnipay'),
                    'desc_tip'    => true,
                    'default'     => 'physical',
                    'options'     => [
                        'physical'            => __('Physical Product (Set to processing)', 'woocommerce-omnipay'),
                        'digital_processing'  => __('Digital Product (Set to processing)', 'woocommerce-omnipay'),
                        'digital_complete'    => __('Digital Product (Auto complete)', 'woocommerce-omnipay'),
                    ],
                ],
                'apikey' => [
                    'title' => __('Store API Key', 'woocommerce-omnipay'),
                    'type' => 'password',
                    'description' => __('Your OmniPay Store API key.', 'woocommerce-omnipay'),
                    'default' => '',
                    'desc_tip' => true,
                ],
                'baseUrl' => [
                    'title' => __('API Base URL', 'woocommerce-omnipay'),
                    'type' => 'text',
                    'description' => __('Your OmniPay API Base URL.', 'woocommerce-omnipay'),
                    'default' => 'http://localhost:8000',
                    'desc_tip' => true,
                ],
            ];
        }

        public function process_payment($order_id)
        {
            $order = wc_get_order($order_id);
            if (!$order) {
                wc_add_notice(__('Order not found.', 'woocommerce-omnipay'), 'error');
                return ['result' => 'fail'];
            }
            
            $data = [
                'amount'         => (string) $order->get_total(),
                'customer_name'  => sanitize_text_field(trim(($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()) ?: 'Client')),
                'customer_email' => sanitize_email($order->get_billing_email() ?: 'customer@omnipay.com'),
                'currency'       => $order->get_currency(),
                'callback_url'   => WC()->api_request_url(strtolower($this->id)),
                'cancel_url'     => wc_get_checkout_url(),
                'meta_data'      => ['order_id' => (string) $order->get_id()],
            ];
        
            $args = [
                'body'    => json_encode($data),
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                    'X-API-KEY'    => $this->apikey,
                ],
                'timeout' => 45,
            ];
        
            $response = wp_remote_post(rtrim($this->baseUrl, '/') . '/api/v1/payment', $args);
        
            if (is_wp_error($response)) {
                wc_add_notice(__('Payment error: ', 'woocommerce-omnipay') . $response->get_error_message(), 'error');
                return ['result' => 'fail'];
            }
        
            $result = json_decode(wp_remote_retrieve_body($response), true);
        
            if (isset($result['payment_link'])) {
                return [
                    'result'   => 'success',
                    'redirect' => esc_url_raw($result['payment_link']),
                ];
            }
    
            $message = !empty($result['error']) ? esc_html($result['error']) : __('Unknown error.', 'woocommerce-omnipay');
            wc_add_notice(sprintf(__('Payment error: Unable to create payment link. %s', 'woocommerce-omnipay'), $message), 'error');
            return ['result' => 'fail'];
        }
        
        public function handle_webhook()
        {
            $raw     = file_get_contents("php://input");
            $payload = json_decode($raw, true);
            $headers = getallheaders();

            $received_signature = '';
            if (isset($headers['X-OMNIPAY-SIGNATURE'])) {
                $received_signature = $headers['X-OMNIPAY-SIGNATURE'];
            } elseif (isset($headers['x-omnipay-signature'])) {
                $received_signature = $headers['x-omnipay-signature'];
            } elseif (isset($_SERVER['HTTP_X_OMNIPAY_SIGNATURE'])) {
                $received_signature = $_SERVER['HTTP_X_OMNIPAY_SIGNATURE'];
            }

            $expected_signature = hash_hmac('sha256', $raw, $this->apikey);

            if (empty($received_signature) || !hash_equals($expected_signature, $received_signature)) {
                status_header(401);
                wp_send_json_error(['message' => 'Unauthorized signature.']);
                exit;
            }

            if (empty($payload['invoice_id']) || empty($payload['status'])) {
                status_header(400);
                wp_send_json_error(['message' => 'Missing required data.']);
                exit;
            }

            $status = strtolower($payload['status']);
            $order_id = isset($payload['meta_data']['order_id']) ? absint($payload['meta_data']['order_id']) : 0;
            $invoice_id = sanitize_text_field($payload['invoice_id']);

            $order = wc_get_order($order_id);
            if (!$order) {
                status_header(404);
                wp_send_json_error(['message' => 'Order not found.']);
                exit;
            }

            if ($status === 'paid') {
                $order->update_meta_data('_omnipay_invoice_id', $invoice_id);
                $order->save();

                $order_type = $this->order_type;
                if ($order_type === 'physical') {
                    $order->update_status('processing', __('Physical product order set to processing by OmniPay.', 'woocommerce-omnipay'));
                } elseif ($order_type === 'digital_processing') {
                    $order->update_status('processing', __('Digital product order set to processing by OmniPay.', 'woocommerce-omnipay'));
                } elseif ($order_type === 'digital_complete') {
                    $order->update_status('completed', __('Digital product order completed automatically by OmniPay.', 'woocommerce-omnipay'));
                }
                $order->payment_complete();
                $order->add_order_note(__('Payment verified via OmniPay webhook.', 'woocommerce-omnipay'));
                
                status_header(200);
                wp_send_json_success(['message' => 'Success']);
                exit;
            } else {
                $order->update_status('failed', __('Payment failed or cancelled via OmniPay webhook.', 'woocommerce-omnipay'));
                status_header(200);
                wp_send_json_success(['message' => 'Payment status updated to failed']);
                exit;
            }
        }

        public function display_omnipay_order_meta($order) {
            $invoice_id = $order->get_meta('_omnipay_invoice_id', true);

            echo '<h3>' . __('OmniPay Details', 'woocommerce-omnipay') . '</h3>';
            if ($invoice_id) {
                echo '<p><i class="fa fa-arrow-right"></i> <strong>' . __('Invoice ID:', 'woocommerce-omnipay') . '</strong> ' . esc_html($invoice_id) . '</p>';
            } else {
                echo '<p><i class="fa fa-arrow-right"></i> <strong>' . __('Invoice ID:', 'woocommerce-omnipay') . '</strong> ' . __('N/A (Pending payment)', 'woocommerce-omnipay') . '</p>';
            }
        }
    }

    // Define server-side integration for blocks
    class WC_OMNIPAY_Blocks extends \Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType
    {
        protected $name = 'omnipay';

        public function initialize()
        {
            $this->settings = get_option('woocommerce_omnipay_settings', []);
        }

        public function is_active()
        {
            return !empty($this->settings['enabled']) && 'yes' === $this->settings['enabled'];
        }

        public function get_payment_method_script_handles()
        {
            wp_register_script(
                'omnipay-blocks',
                plugins_url('assets/js/omnipay-blocks.js', __FILE__),
                ['wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-i18n'],
                filemtime(plugin_dir_path(__FILE__) . '/assets/js/omnipay-blocks.js'),
                true
            );
            return ['omnipay-blocks'];
        }

        public function get_payment_method_data()
        {
            $gateway = WC_OMNIPAY_Gateway::get_instance();
            return [
                'title' => $gateway->title,
                'description' => $gateway->description,
                'icon' => $gateway->icon,
                'supports' => ['products'],
            ];
        }
    }

    // Register payment method for WooCommerce Blocks
    add_action('woocommerce_blocks_payment_method_type_registration', function ($registry) {
        $registry->register(new WC_OMNIPAY_Blocks());
    });

    // Add filter to include payment gateway
    add_filter('woocommerce_payment_gateways', function ($gateways) {
        $gateways[] = 'WC_OMNIPAY_Gateway';
        return $gateways;
    });
}