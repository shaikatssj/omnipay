=== WooCommerce OmniPay Gateway ===
Contributors: omnipay
Tags: payment, gateway, WooCommerce, omnipay, crypto, mfs
Tested up to: 6.8
WC requires at least: 3.0
WC tested up to: 8.0
Stable tag: 1.0.0
License: GPLv2 or later

Accept payments securely via OmniPay payment gateway.

== Description ==
OmniPay Gateway provides a simple and secure way to accept Mobile Financial Services (MFS), Web3 Crypto, and Binance Pay on your WooCommerce store.

== Installation ==
1. Upload the `woocommerce-omnipay` directory to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to WooCommerce > Settings > Payments and enable OmniPay Gateway.